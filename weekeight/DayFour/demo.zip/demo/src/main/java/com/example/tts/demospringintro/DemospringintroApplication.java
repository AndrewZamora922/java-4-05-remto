package com.example.tts.demospringintro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringintroApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemospringintroApplication.class, args);
	}

}
