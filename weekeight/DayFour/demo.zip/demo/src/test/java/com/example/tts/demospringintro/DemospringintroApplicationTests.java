package com.example.tts.demospringintro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemospringintroApplicationTests {

	@Test
	void contextLoads() {
	}

}
