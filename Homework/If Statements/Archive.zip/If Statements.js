let coffee = 28;

if (coffee<=3){
    console.log("Yes I'll take another cup of coffee.")
}else {
    console.log("I think I'm okay for now.")
}
  

let miles = 2900;

if (miles<=500){
    console.log('Yes I think I need an oil change')
}else {
    console.log(`My car doesn't need an oil change yet`)
}