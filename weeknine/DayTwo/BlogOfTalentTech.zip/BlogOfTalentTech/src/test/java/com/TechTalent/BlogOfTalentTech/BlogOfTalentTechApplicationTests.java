package com.TechTalent.BlogOfTalentTech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogOfTalentTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
