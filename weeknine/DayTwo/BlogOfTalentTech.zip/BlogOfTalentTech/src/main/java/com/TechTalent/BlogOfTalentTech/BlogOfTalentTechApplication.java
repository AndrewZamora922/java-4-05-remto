package com.TechTalent.BlogOfTalentTech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogOfTalentTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogOfTalentTechApplication.class, args);
	}

}
